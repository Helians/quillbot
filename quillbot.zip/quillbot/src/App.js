import React from 'react';
import { useState } from 'react';
import './App.css';

let wordmatch = [
  {
    startIndex: 4,
    endIndex: 6,
    replacement: 'only',
    original: 'oly',
  },
  {
    startIndex: 25,
    endIndex: 28,
    replacement: 'fear',
    original: 'feer',
  },
];



function App() {

  const [isCorrected, setIsCorrected] = useState(false)

  const handleClick = () => {

    let root = document.querySelector('.app__text');
    let textNodeList = [];

    // find all the text nodes and push them in the textNodeList
    const getCheckData = (node) => {
      if (!node) {
        return;
      }

      if (node.nodeType == 3) {
        textNodeList.push(node);
      }

      node.childNodes.forEach(n => {
        getCheckData(n)
      })

    }

    getCheckData(root);

    // process all  text nodes and correct them based on wordmatch
    let currLength = 0;
    let offset = 0;
    let diff = 0;
    let temp = [...wordmatch];
    let charactersToRemove = 0

    for (let i = 0; i < textNodeList.length; i++) {

      let node = textNodeList[i];

      if (charactersToRemove) {
        node.nodeValue = node.nodeValue.replace(node.nodeValue.slice(0, charactersToRemove), '');
        charactersToRemove = 0;
      }

      currLength += node.nodeValue.length;

      while (temp.length) {

        if (temp[0]['startIndex'] >= currLength) {
          break;
        }

        if (temp[0]['startIndex'] >= offset) {
          if (temp[0]['endIndex'] < currLength) {
            node.nodeValue = node.nodeValue.replace(temp[0]['original'], temp[0]['replacement']);
            diff = node.nodeValue.length - currLength;
          } else {
            let currValue = temp[0]['replacement'];
            let str = node.nodeValue.slice(temp[0]['startIndex'] - currLength + diff);
            charactersToRemove = currValue.length - str.length;
            node.nodeValue = node.nodeValue.replace(str, temp[0]['replacement']);
          }
          
          temp.shift();
        }

      }
    }

    setIsCorrected(true);
  }

  // you're
  // u r i ==> you're


  return (
    <div className="app">

      <span className='app__text'>
        <span>The oly thing we have to </span>
        <span className='app__text-blue'>
          <span>f</span>
          <span>eer is fear </span>
        </span>
        <span>itself.</span>
      </span>

      <div><button onClick={handleClick} disabled={isCorrected}>{isCorrected ? 'Data Corrected' : 'Click to Correct'}</button></div>

    </div>
  );
}

export default App;
